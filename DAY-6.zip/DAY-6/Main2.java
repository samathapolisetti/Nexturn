/*INHERITENCE
Inheritance is a feature in Java that allows one class to inherit the properties (variables) and behaviors (methods) of another class. It helps in code reusability and allows us to create a new class based on an existing one.
Parent Class (Superclass) → The existing class whose properties & methods are inherited.
Child Class (Subclass) → The new class that inherits from the parent class.
*/
public class Main2 {
   // Parent Class (Superclass)
    String name;

    public void eat() {
        System.out.println(name + " is eating.");
    }

    public void sleep() {
        System.out.println(name + " is sleeping.");
    }
}

// Child Class (Subclass) inheriting from Animal
class Dog extends Main2 {
    public void bark() {
        System.out.println(name + " is barking.");
    }

// Main class to test
    public static void main(String[] args) {
        Dog myDog = new Dog();  // Creating an object of Dog class
        myDog.name = "Buddy";
        
        myDog.eat();   // Inherited method from Animal
        myDog.sleep(); // Inherited method from Animal
        myDog.bark();  // Method from Dog class
    }
}
 

