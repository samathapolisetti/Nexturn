public class work3 {
    String accountHolder;
    int accountNumber;
    double balance;
    float Depositing;
    float withDrawing;

    // Constructor
    public work3(String accountHolder, int accountNumber, double balance, float Depositing, float withDrawing) {
        this.accountHolder = accountHolder;
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.Depositing = Depositing;
        this.withDrawing = withDrawing;
    }

    // Copy Constructor
    public work3(work3 newwork3) {
        accountNumber = newwork3.accountNumber;
        accountHolder = newwork3.accountHolder;
        balance = newwork3.balance;
        Depositing = newwork3.Depositing;
        withDrawing = newwork3.withDrawing;
    }

    // Display account details
    public void display() {
        System.out.println("Name: " + accountHolder);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }

    public void displayDepositing() {
        System.out.println("Depositing: " + Depositing);
    }

    public void displayWithdrawing() {
        System.out.println("Withdrawing: " + withDrawing);
    }

    // Main method
    public static void main(String[] args) {
        // Creating an object with correct parameters
        work3 account = new work3("Sam Book", 87671, 10000, 5000, 3500);
        
        System.out.println("ACCOUNT DETAILS");
        account.display();

        System.out.println("After Deposit:");
        account.displayDepositing();
        System.out.println("New Balance: " + (account.balance + account.Depositing));

        System.out.println("After Withdrawal:");
        account.displayWithdrawing();
        System.out.println("New Balance: " + (account.balance + account.Depositing - account.withDrawing));
    }
}
