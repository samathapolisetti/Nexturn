/*OBJECT ORIENTED PROGRAMMING(OOPS):
POCEDURAL-PROGRAMMING LANGUAGE:
encapsulation:using encapsulation we can identify programming language
-it is platform independent we can run it anywhere ,capability achieved through java virtual machine so it is highly versatile
TOP-DOWN APPROACH:data is not encapsulated,reusability limited
BOTTOM-UP APPROACH:encapsulated,high reusability

CLASS:
blue-print for creating programme
OBJECT:
instance of class
-there are 5 ways for creating object:
 new-new keyword is the standard way to create an object in Java.
 Person p1 = new Person("Alice");
,factory()-factory method is a static method that returns an instance of a class.
 public static Person factory(String name) {
,clone()-clone() method creates a copy of an existing object instead of creating a new one.
The class must implement Cloneable, and clone() should be overridden.
 Person p1 = new Person("Alice");
 Person p2 = (Person) p1.clone(); // Cloning p1
 
*/
