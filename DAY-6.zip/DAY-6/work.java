public class work {
    String name;
    int  number;
    String grade;
    public static void main(String[] args){
        work p1 = new work();
        System.out.println("Student details :");
        p1.display();
    }
    work(){
        name = "samatha";
        number = 41;
        grade = "A";
    }
    void display(){
        System.out.println("Name :" +" "+name);
        System.out.println("Roll number :"+" "+number);
        System.out.println("grade :"+" " +grade);
       
    }

    
}
