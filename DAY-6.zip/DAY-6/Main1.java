/*CONSTRUCTOR:
-a constructor is a special method that used to initialize a object,set values to the data members  it will automatically create when object is called .
-rules-no return type
      name of the function must be same as the name of class
      we can have multiple constructors with different signature
-we get a default value-0 when we use int object,we get null when we use string object
PARAMETERIZED CONSTRUCTOR:
      Person(String personName) {
        name = personName;
CONSTRUCTOR OVERLOADING:
You can have multiple constructors in the same class with different parameters.
      // Constructor 1 - No Parameters
    Person() {
        name = "Unknown";
        age = 0;
    }

    // Constructor 2 - One Parameter
    Person(String personName) {
        name = personName;
        age = 0;
    }

    // Constructor 3 - Two Parameters
    Person(String personName, int personAge) {
        name = personName;
        age = personAge;
COPY CONSTRUCTOR:
   Person(Person otherPerson) {
        name = otherPerson.name;
   }
CONSTRUCTOR USING THIS METHOD:
The this keyword helps refer to the current instance of a class.
    Person(String name) {
        this.name = name; // 'this' refers to the instance variable
    }
 
class Person{
    String name;
    //default constructor
    Person(){
        System.out.println("Constructor called");
        name="Samatha";
    }
}
public class Main1{
    public static void main(String[] args){
        Person p1 = new Person();//constructor calls automatically
        System.out.println("Name:" + p1.name);

    }
}*/

public class Main1{
    String name;
    int num;

        public static void main(String[] args){
            //class name and object creating name must be same 
            Main1 p1 = new Main1();//constructor calls automatically
            System.out.println("Name:" + p1.name);
            p1.show();
        }

    //constructor method:
    Main1(){
        //default constructor
        name="ramesh";
        num=1234;
                                          //constructor overloading 
    }
    
    void show(){
        System.out.println(name+""+num);
    }
    //parameterized method
    Main1(String a,int b){
        name = a;
        num = b;
    }

    void show1(){
        System.out.println(name+""+num);

    }

}
