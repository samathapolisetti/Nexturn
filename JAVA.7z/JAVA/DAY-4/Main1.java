//STRING BUILDER:

/*
append(String str)	                  Appends the specified string to the end of the StringBuilder.	                          sb.append("Geeks");
insert(int offset, String)	          Inserts the specified string at the given position in the StringBuilder.	              sb.insert(5, " Geeks");
replace(int start, int end, String)	  Replaces characters in a substring with the specified string.	                          sb.replace(6, 11, "Geeks");
delete(int start, int end)	          Removes characters in the specified range.	                                          sb.delete(5, 11);
reverse()	                          Reverses the sequence of characters in the StringBuilder.	                              sb.reverse();
capacity()	                          Returns the current capacity of the StringBuilder.	                                  int cap = sb.capacity();
length()	                          Returns the number of characters in the StringBuilder.	                              int len = sb.length();
charAt(int index)	                  Returns the character at the specified index.	                                          char ch = sb.charAt(4);
setCharAt(int index, char)	          Replaces the character at the specified position with a new character.                  sb.setCharAt(0, 'G');
substring(int start, int end)	      Returns a new String that contains characters from the specified range.	              String sub = sb.substring(0, 5);
ensureCapacity(int minimum)	          Ensures the capacity of the StringBuilder is at least equal to the specified minimum.	  sb.ensureCapacity(50);
deleteCharAt(int index)	              Removes the character at the specified position.	                                      sb.deleteCharAt(3);
indexOf(String str)	                  Returns the index of the first occurrence of the specified string.	                  int idx = sb.indexOf("Geeks");
lastIndexOf(String str)	              Returns the index of the last occurrence of the specified string.	                      int idx = sb.lastIndexOf("Geeks");
toString()	                          Converts the StringBuilder object to a String.	                                      String result = sb.toString();

//STRING BUFFER:

append()	                          Used to add text at the end of the existing text.
length()	                          The length of a StringBuffer can be found by the length( ) method.
capacity()	                          the total allocated capacity can be found by the capacity( ) method.
charAt()	                          This method returns the char value in this sequence at the specified index.
delete()	                          Deletes a sequence of characters from the invoking object.
deleteCharAt()	                      Deletes the character at the index specified by the loc.
ensureCapacity()	                  Ensures capacity is at least equal to the given minimum.
insert()	                          Inserts text at the specified index position.
length()	                          Returns the length of the string.  
reverse()	                          Reverse the characters within a StringBuffer object.
replace()	                          Replace one set of characters with another set inside a StringBuffer object.
*/
public class Main1 {
    public static void main(String[] args){
        StringBuilder name = new StringBuilder("samatha");
        name.append(" welcome");
        System.out.println(name);
        StringBuffer name1 = new StringBuffer("hello ");
        name1.append(" world");
        System.out.println(name1);
    }
  
    
}
