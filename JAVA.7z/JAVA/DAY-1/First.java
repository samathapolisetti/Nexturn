//LOCAL VARIABLE
/*public class First {
    public static void main(String[] args){
        int var = 10;
        System.out.println("local variable: "+var);

    }
    
}

//STATIC VARIABLE
public class First{
    public static  String geek = "samatha";

    public static void main(String[] args){
        System.out.println("String is:"+ geek);
    }
}

//INSTANCE VARIABLE
public class First {  
    public String name;  
    public int age=19;  
    public InstanceVariableDemo()  
    {  
        this.name = "Deepak";  
    }  
    public static void main(String[] args)  
    {  
        // Object Creation  
       InstanceVariableDemo obj = new InstanceVariableDemo();  
        System.out.println("Student Name is: " + obj.name);  
        System.out.println("Age: "+ obj.age);  
    }  
}  */

