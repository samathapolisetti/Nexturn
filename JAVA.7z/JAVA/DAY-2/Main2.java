class DefaultEx{
    int samatha=30;
}
public class Main2 {
    public static void main(String[] args){
        DefaultEx obj = new DefaultEx();
        System.out.println(obj.samatha);

    }
}
