 class Privateaccess{
    private int secretecode=2004;//used to prevent unauthorized access 
     void showcode(){//void method does not return any value
        System.err.println(secretecode);//err used to identify errors
     }
}

public class Main{
    public static void main(String[] args){
        Privateaccess obj= new Privateaccess();
        obj.showcode();
    }
} 
    

