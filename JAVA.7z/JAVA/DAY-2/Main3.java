public class Main3 {
    
}
