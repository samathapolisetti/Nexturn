public class work {
    public static void main(String[] args) {
        System.out.println("Using For Loop:");
        forLoopPattern();

        System.out.println("\nUsing While Loop:");
        whileLoopPattern();

        System.out.println("\nUsing Do-While Loop:");
        doWhileLoopPattern();
    }

    // Using For Loop
    public static void forLoopPattern() {
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j + " ");
            }
            System.out.println();
        }
    }

    // Using While Loop
    public static void whileLoopPattern() {
        int i = 1;
        while (i <= 5) {
            int j = 1;
            while (j <= i) {
                System.out.print(j + " ");
                j++;
            }
            System.out.println();
            i++;
        }
    }

    // Using Do-While Loop
    public static void doWhileLoopPattern() {
        int i = 1;
        do {
            int j = 1;
            do {
                System.out.print(j + " ");
                j++;
            } while (j <= i);
            System.out.println();
            i++;
        } while (i <= 5);
    }
}
