public class work2 {
        public static void main(String[] args) {
            System.out.println("using for loop:");
            forLoopPattern();
            System.out.println("using for whileloop:");
            whileLoopPattern();
            System.out.println("using for dowhileloop:");
            dowhileLoopPattern();
            
        }
        public static void forLoopPattern(){
            int rows = 3;  // Number of rows
            int num = 1;    // Counter for numbers
            for (int i = 1; i <= rows; i++) {
                // Printing leading spaces
                for (int space = 1; space <= (rows - i) * 2; space++) {
                    System.out.print(" ");
                }
                // Printing numbers
                for (int j = 1; j <= (2 * i - 1); j++) {
                    System.out.print(num + " ");
                    num++; // Increment number
                }
                System.out.println(" ");
             } // Move to next line
            }
        public static void whileLoopPattern(){
            int rows = 3;
        int i = 1, num = 1;

        while (i <= rows) {
            int space = 1;
            while (space <= (rows - i) * 2) {
                System.out.print(" ");
                space++;
            }

            int j = 1;
            while (j <= (2 * i - 1)) {
                System.out.print(num + " ");
                num++;
                j++;
            }

            System.out.println();
            i++;
        }

        }
        public static void dowhileLoopPattern(){
            int rows = 3;
        int i = 1, num = 1;

        do {
            int space = 1;
            do {
                System.out.print(" ");
                space++;
            } while (space <= (rows - i) * 2);

            int j = 1;
            do {
                System.out.print(num + " ");
                num++;
                j++;
            } while (j <= (2 * i - 1));

            System.out.println();
            i++;
        } while (i <= rows);
    }


        }
        
    
    
