/*LOOPS
//-FOR LOOP      :when we know exactly how many times you want to loop through a block of code
For(initialization;condition;update){
      //code block
}
eg:for(int i = 1; i <= 5; i++) {
      System.out.println("Iteration: " + i);
  }
  
//-WHILE LOOP    :Executes the loop body as long as the condition remains true.
while(condition) {
      // Code to be executed
  }
 eg: int i = 1;
  while(i <= 5) {
      System.out.println("Iteration: " + i);
      i++;
  }
    
//-DO WHILE LOOP : Similar to the while loop, but it executes at least once because the condition is checked after executing the loop body.
do {
      // Code to be executed
  } while(condition);
eg:int i = 1;
do {
    System.out.println("Iteration: " + i);
    i++;
} while(i <= 5);*/


  
