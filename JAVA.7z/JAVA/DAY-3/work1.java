public class work1 {
    public static void main(String[] args){
        System.out.println("usingforloop:");
        forloopPattern();
        System.out.println("usingwhileloop:");
        whileloopPattern();
        System.out.println("usingdowhile:");
        doWhileLoopPattern();
 }
        public static void forloopPattern(){
        for(int i=1;i<=3;i++){
            System.out.println(i);
            for(int j=1;j<=4;j++){
                System.out.println(j+" ");
        } 
        System.out.println();
    } 
 }
        public static void  whileloopPattern(){
            int i = 1;
        while (i <= 3) {
            System.out.println(i);  // Print row number
            int j = 1;
            while (j <= 4) {
                System.out.print(j + " ");
                j++;
            }
            System.out.println(); // Move to next line
            i++;
        }

    }
        public static void doWhileLoopPattern(){
            int i = 1;
        do {
            System.out.println(i);  // Print row number
            int j = 1;
            do {
                System.out.print(j + " ");
                j++;
            } while (j <= 4);
            System.out.println(); // Move to next line
            i++;
        } while (i <= 3);

       }
    }

