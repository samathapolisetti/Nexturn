/*CONSOLE
CONSOLE METHODS:
readLine    : reads the line and gives output 
readPassword: hides the password
*/
import java.io.Console;
public class Main3 {
    public static void main(String[] args){
        Console console = System.console();
        if(console==null){
            System.out.println("no console");
            return;
        }
        String username = console.readLine("enter name:");
        char[] passwordChars=console.readPassword("enter password:");
        String password = new String(passwordChars);
        System.out.println("username:"+username);
        System.out.println("password entered:"+password);
    }
    
}
