/*COMMAND LINE ARGUMENTS
Command line arguments in Java allow users to pass input values to a program when executing it from the terminal or command prompt
ParseInt -it converts a string (e.g., "5") into its corresponding integer value (5).*/
public class Main4 {
    public static void main(String[] args){
       if(args.length<2){
          System.out.println("enter provide your name and age in command-line arguments:");
          return;
       }
          String name = args[0];  // First argument

            int age = Integer.parseInt(args[1]);  // Second argument

   

            System.out.println("Hello " + name + ", you are " + age + " years old.");
       }   
     }
 
