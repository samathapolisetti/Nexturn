/*BUFFERED READER PACKAGES:
  BUFFERED READER
  INPUTSTREAM READER
  IOEXCEPTION
* METHODS OF BUFFERED READER:
read():                   Reads a single character
read(char[], int, int):   Reads characters into a portion of an array
readLine():               Reads a line of text
ready():                  Checks if the stream is ready to be read
reset():                  Resets the stream to the most recent mark
close():                  Closes the stream and releases any system resources associated with it
mark(int readAheadLimit): Marks the present position in the stream
markSupported():          Tells whether this stream supports the mark() operation
skip(long n):             Skips characters
lines():                  Returns a Stream, the elements of which are lines read from this BufferedReader

 */
import java.io.BufferedReader;//to take large amount of input
import java.io.IOException;//input , output reading
import java.io.InputStreamReader;//bytes converted into characters

public class Main2{
   public static void main(String[] args) throws IOException{
    InputStreamReader name = new InputStreamReader(System.in);
    BufferedReader Br=new BufferedReader(name);
    System.out.println("Enter your Name");
    String myname = Br.readLine();

    System.out.println("hello, "+ myname +"!");

   } 
}