/* ABSTRACTION:hides implementation details and shows only the essential part 
-abstraction using class
-abstraction using interface
Demonstrating Abstraction in Java*/
//ABSTRACTION USING CLASS
abstract class Geeks {
    abstract void turnOn();
    abstract void turnOff();
}

// Concrete class implementing the abstract methods
class TVRemote extends Geeks {
    @Override
    void turnOn() {
        System.out.println("TV is turned ON.");
    }

    @Override
    void turnOff() {
        System.out.println("TV is turned OFF.");
    }
}

// Main class to demonstrate abstraction
public class Main {
    public static void main(String[] args) {
        Geeks remote = new TVRemote();
        remote.turnOn();   
        remote.turnOff();  
    }
}

//ABSTRACTION USING INTERFACE
// Interface
/*interface Vehicle {
    void start();  // Abstract method (no body)
}

// Implementing the interface in a class
class Car implements Vehicle {
    public void start() {  // Defining the abstract method
        System.out.println("Car starts with a key.");
    }
}

// Main class to test
public class InterfaceExample {
    public static void main(String[] args) {
        Car myCar = new Car();
        myCar.start();  // Calls the method from Car class
    }
}
*/
