/*
//JAGGED ARRAY
we can create a 2-D array but with a variable number of columns in each row.
eg:arr [][]= { {1,2}, {3,4,5,6},{7,8,9}};
int myarray[][] = new int[3][];*/
public class Main3 {
    public static void main(String[] args){

    }
 
    
}
