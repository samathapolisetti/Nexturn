import java.util.*;
public class Work2 {
    public static void main(String[] args){
        final int CORRECT_PIN = 1234;
        int attempts = 3;
        Scanner sc = new Scanner(System.in);
        
        while(attempts>0){
            System.out.println("enter your atm pin:");
            int enteredpin = sc.nextInt();
            

        if(enteredpin==CORRECT_PIN){
            System.out.println("entered atm pin is correct");
            sc.close();
            return;
        }
        else {
            if (attempts > 0) {
                System.out.println("Incorrect PIN. You have " + attempts + " attempt(s) left.");
                sc.close();
            } else {
                System.out.println("Incorrect PIN entered 3 times. Your account is locked.");
            }
        }
    }

}
}
  


    
 