//take input from user and print using while loop
import java.util.*;
public class Work{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int i=1;
    while(num>5){
        System.out.println(num);
    }
}
}